"""Cliente para Finviz (scraping como backup)."""

import time
from typing import Optional

import httpx
from bs4 import BeautifulSoup
from loguru import logger


class FinvizClient:
    """
    Cliente para scraping de Finviz.
    Usar con moderación - respetar rate limits.
    """
    
    BASE_URL = "https://finviz.com/screener.ashx"
    DELAY_SECONDS = 5  # Delay entre requests
    
    # Mapeo de filtros a parámetros Finviz
    FILTER_MAP = {
        "market_cap_min_2b": "cap_largeover",
        "market_cap_min_10b": "cap_mega",
        "pe_positive": "fa_pe_profitable",
        "peg_under_1": "fa_peg_low",
        "roe_over_15": "fa_roe_o15",
        "current_ratio_over_1.5": "fa_curratio_o1.5",
        "quick_ratio_over_1": "fa_quickratio_o1",
        "debt_equity_under_0.5": "fa_debteq_u0.5",
    }
    
    def __init__(self, delay: float = None):
        self.delay = delay or self.DELAY_SECONDS
        self.last_request = 0
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        self.client = httpx.Client(timeout=30, headers=self.headers)
    
    def _wait(self):
        """Espera entre requests para no saturar."""
        elapsed = time.time() - self.last_request
        if elapsed < self.delay:
            time.sleep(self.delay - elapsed)
        self.last_request = time.time()
    
    def screen(self, filters: list[str] = None) -> list[dict]:
        """
        Ejecuta screener en Finviz.
        
        Args:
            filters: Lista de filtros (ver FILTER_MAP)
        
        Returns:
            Lista de diccionarios con datos básicos
        """
        self._wait()
        
        # Construir URL con filtros
        filter_str = ",".join(filters or [])
        params = {"v": "111", "f": filter_str}  # v=111 = vista overview
        
        logger.info(f"Finviz scraping con filtros: {filter_str}")
        
        response = self.client.get(self.BASE_URL, params=params)
        response.raise_for_status()
        
        return self._parse_table(response.text)
    
    def _parse_table(self, html: str) -> list[dict]:
        """Parsea tabla de resultados."""
        soup = BeautifulSoup(html, "lxml")
        
        # Buscar tabla de resultados
        table = soup.find("table", {"id": "screener-content"})
        if not table:
            logger.warning("No se encontró tabla de resultados")
            return []
        
        results = []
        rows = table.find_all("tr")[1:]  # Skip header
        
        for row in rows:
            cols = row.find_all("td")
            if len(cols) < 10:
                continue
            
            try:
                results.append({
                    "symbol": cols[1].text.strip(),
                    "name": cols[2].text.strip(),
                    "sector": cols[3].text.strip(),
                    "industry": cols[4].text.strip(),
                    "country": cols[5].text.strip(),
                    "market_cap": self._parse_market_cap(cols[6].text),
                    "pe": self._parse_float(cols[7].text),
                    "price": self._parse_float(cols[8].text),
                    "change": cols[9].text.strip(),
                    "volume": self._parse_int(cols[10].text),
                })
            except (IndexError, ValueError) as e:
                logger.debug(f"Error parseando fila: {e}")
                continue
        
        logger.info(f"Finviz: {len(results)} resultados")
        return results
    
    def _parse_market_cap(self, text: str) -> Optional[float]:
        """Parsea market cap (ej: '2.5B' -> 2500000000)."""
        text = text.strip().upper()
        if not text or text == "-":
            return None
        
        multipliers = {"K": 1e3, "M": 1e6, "B": 1e9, "T": 1e12}
        
        for suffix, mult in multipliers.items():
            if text.endswith(suffix):
                return float(text[:-1]) * mult
        
        return float(text)
    
    def _parse_float(self, text: str) -> Optional[float]:
        """Parsea float, retorna None si inválido."""
        text = text.strip().replace(",", "")
        if not text or text == "-":
            return None
        try:
            return float(text)
        except ValueError:
            return None
    
    def _parse_int(self, text: str) -> Optional[int]:
        """Parsea int, retorna None si inválido."""
        text = text.strip().replace(",", "")
        if not text or text == "-":
            return None
        try:
            return int(text)
        except ValueError:
            return None
    
    def get_garp_filters(self) -> list[str]:
        """Retorna filtros predefinidos para estrategia GARP."""
        return [
            "cap_largeover",      # Market Cap > $2B
            "fa_pe_profitable",   # P/E positivo
            "fa_peg_low",         # PEG < 1
            "fa_roe_o15",         # ROE > 15%
            "fa_curratio_o1.5",   # Current Ratio > 1.5
            "fa_quickratio_o1",   # Quick Ratio > 1
            "fa_debteq_u0.5",     # D/E < 0.5
        ]
    
    def close(self):
        """Cierra el cliente HTTP."""
        self.client.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
