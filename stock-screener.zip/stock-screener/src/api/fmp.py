"""Cliente para Financial Modeling Prep API."""

import os
from typing import Optional
from datetime import datetime

import httpx
from loguru import logger

from src.models.stock import Stock, StockMetrics


class FMPClient:
    """Cliente para interactuar con Financial Modeling Prep API."""
    
    BASE_URL = "https://financialmodelingprep.com/api/v3"
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("FMP_API_KEY")
        if not self.api_key:
            raise ValueError("FMP_API_KEY no configurada")
        self.client = httpx.Client(timeout=30)
    
    def _request(self, endpoint: str, params: dict = None) -> dict | list:
        """Realiza request a la API."""
        params = params or {}
        params["apikey"] = self.api_key
        
        url = f"{self.BASE_URL}/{endpoint}"
        logger.debug(f"GET {endpoint}")
        
        response = self.client.get(url, params=params)
        response.raise_for_status()
        return response.json()
    
    def screen_stocks(
        self,
        market_cap_min: float = 2e9,
        price_min: float = 5,
        volume_min: int = 300000,
        exchange: list[str] = None,
    ) -> list[dict]:
        """
        Obtiene lista de stocks que pasan filtros básicos.
        
        Args:
            market_cap_min: Market cap mínimo en USD
            price_min: Precio mínimo
            volume_min: Volumen promedio mínimo
            exchange: Lista de exchanges (NYSE, NASDAQ)
        
        Returns:
            Lista de stocks con datos básicos
        """
        params = {
            "marketCapMoreThan": int(market_cap_min),
            "priceMoreThan": price_min,
            "volumeMoreThan": volume_min,
            "isActivelyTrading": "true",
            "isEtf": "false",
            "isFund": "false",
        }
        
        if exchange:
            params["exchange"] = ",".join(exchange)
        
        return self._request("stock-screener", params)
    
    def get_ratios(self, symbol: str) -> dict:
        """Obtiene ratios financieros de un símbolo."""
        data = self._request(f"ratios/{symbol}")
        return data[0] if data else {}
    
    def get_key_metrics(self, symbol: str) -> dict:
        """Obtiene métricas clave de un símbolo."""
        data = self._request(f"key-metrics/{symbol}")
        return data[0] if data else {}
    
    def get_financial_growth(self, symbol: str) -> dict:
        """Obtiene métricas de crecimiento."""
        data = self._request(f"financial-growth/{symbol}")
        return data[0] if data else {}
    
    def get_company_profile(self, symbol: str) -> dict:
        """Obtiene perfil de la compañía."""
        data = self._request(f"profile/{symbol}")
        return data[0] if data else {}
    
    def build_stock(self, symbol: str, basic_data: dict = None) -> Stock:
        """
        Construye objeto Stock completo con todas las métricas.
        
        Args:
            symbol: Símbolo de la acción
            basic_data: Datos básicos del screener (opcional)
        
        Returns:
            Stock con métricas completas
        """
        # Obtener datos si no se proporcionaron
        if not basic_data:
            basic_data = self.get_company_profile(symbol)
        
        # Obtener métricas adicionales
        ratios = self.get_ratios(symbol)
        key_metrics = self.get_key_metrics(symbol)
        growth = self.get_financial_growth(symbol)
        
        # Construir métricas
        metrics = StockMetrics(
            # Valuación
            pe_ratio=basic_data.get("pe") or ratios.get("priceEarningsRatio"),
            peg_ratio=ratios.get("priceEarningsToGrowthRatio"),
            pb_ratio=ratios.get("priceToBookRatio"),
            ps_ratio=ratios.get("priceToSalesRatio"),
            
            # Crecimiento
            eps_growth_5y=growth.get("fiveYEpsGrowthPerShare"),
            revenue_growth_5y=growth.get("fiveYRevenueGrowthPerShare"),
            
            # Rentabilidad
            roe=ratios.get("returnOnEquity"),
            roa=ratios.get("returnOnAssets"),
            gross_margin=ratios.get("grossProfitMargin"),
            operating_margin=ratios.get("operatingProfitMargin"),
            net_margin=ratios.get("netProfitMargin"),
            
            # Liquidez
            current_ratio=ratios.get("currentRatio"),
            quick_ratio=ratios.get("quickRatio"),
            
            # Solvencia
            debt_to_equity=ratios.get("debtEquityRatio"),
            interest_coverage=ratios.get("interestCoverage"),
        )
        
        return Stock(
            symbol=symbol,
            name=basic_data.get("companyName", ""),
            exchange=basic_data.get("exchangeShortName", ""),
            sector=basic_data.get("sector", ""),
            industry=basic_data.get("industry", ""),
            price=basic_data.get("price", 0),
            market_cap=basic_data.get("mktCap", 0),
            avg_volume=basic_data.get("volAvg", 0),
            metrics=metrics,
            last_updated=datetime.now(),
            data_source="fmp",
        )
    
    def close(self):
        """Cierra el cliente HTTP."""
        self.client.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        self.close()
