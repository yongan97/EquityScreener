"""Tests del Stock Screener."""
